-- Portable TL build --

TL is a free alternative launcher for Minecraft.
This is an example on how you can to create portable Minecraft installations.

How do I start it? TL.exe (don't rename it btw)
How do I use it? https://tlaun.ch/wiki/en:guide:portable-client

-- Портативная сборка TL --

TL – свободный и бесплатный лаунчер для Minecraft.
Данная сборка содержит минимальный набор файлов для создания портативной сборки TL

Как запустить? TL.exe (переименовывать не рекомендуется)
Как использовать? https://tlaun.ch/wiki/guide:portable-client

--

TL 1.154.2
2023-02-01
